# -*- coding: utf-8 -*-

'''
    Filmnet Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib, urlparse, re

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import source_utils
from resources.lib.modules import dom_parser
from resources.lib.modules import trakt



class source:
    def __init__(self):
        self.priority = 1
        self.language = ['gr']
        self.domains = ['tainiomania.ucoz.com']
        self.base_link = 'http://tainiomania.ucoz.com'
        self.search_link = 'search/?q=%s'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = self.__search([localtitle] + source_utils.aliases_to_array(aliases), year, 'movie')
            if not url and title != localtitle: url = self.__search([title] + source_utils.aliases_to_array(
                aliases),year, 'movie')
            if not url: url = self.__search(trakt.getMovieTranslation(imdb, 'el'), year, 'movie')
            return url
        except:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = self.__search([localtvshowtitle] + source_utils.aliases_to_array(aliases), year, 'show')
            if not url and tvshowtitle != localtvshowtitle: url = self.__search(
                [tvshowtitle] + source_utils.aliases_to_array(aliases), year, 'show')
            return url
        except:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url:
                return
            url = [{'url': url, 'season': season, 'episode': episode}]
            return url
        except:
            return

    def __search(self, titles, year, content):
        try:
            query = [self.search_link % (urllib.quote_plus(cleantitle.getsearch(i))) for i in titles]

            query = [urlparse.urljoin(self.base_link, i) for i in query]

            t = [cleantitle.get(i) for i in set(titles) if i]

            for u in query:
                try:
                    r = client.request(u)
                    r = dom_parser.parse_dom(r, 'div', attrs={'class': 'v_pict'})
                    for i in r:
                        title = re.findall('alt="(.+?)"', i.content, re.DOTALL)[0]
                        y = re.findall('(\d{4})', title, re.DOTALL)[0]
                        title = re.sub('<\w+>|</\w+>', '', title)
                        title = cleantitle.get(title)
                        title = re.sub(y, '', title)
                        title = re.findall('(\w+)', title)[0]
                        if 'show' in content:
                            title = re.sub('\d*', '', title)
                            if title in t:
                                url = re.findall('href="(.+?)"', i[1], re.DOTALL)[0]
                                return source_utils.strip_domain(url)

                        else:
                            if title in t and year == y:
                                url = re.findall('href="(.+?)"', i[1], re.DOTALL)[0]
                                return source_utils.strip_domain(url)
                except:pass
            return
        except:
            return


    def sources(self, url, hostDict, hostprDict):
        sources = []

        try:
            if not url:
                return sources

            if type(url) is list:
                url = url[0]
                query, season, episode = url['url'], url['season'], url['episode']
                query = urlparse.urljoin(self.base_link, query)
                data = client.request(query)
                url = re.findall('''pl=(.+?.txt)["']''', data, re.DOTALL)[0]
                query = urlparse.urljoin(self.base_link, url)
                data = client.request(query)
                sep = '%dx%02d' % (int(season), int(episode))
                url = re.findall('''file['"]:['"]([^"']+\.mp4)["']''', data, re.DOTALL)
                url = [i for i in url if sep in str(i)][0]
                quality = 'SD'
                lang, info = 'gr', 'SUB'

                sources.append({'source': 'DL', 'quality': quality, 'language': lang, 'url': url, 'info': info,
                                'direct': True, 'debridonly': False})

            else:
                query = urlparse.urljoin(self.base_link, url)
                data = client.request(query)
                url = re.findall('''file:['"]([^"']+\.mp4)["']''', data, re.DOTALL)[0]
                quality = 'SD'
                lang, info = 'gr', 'SUB'

                sources.append({'source': 'DL', 'quality': quality, 'language': lang, 'url': url, 'info': info,
                                'direct':True,'debridonly': False})

            return sources
        except:
            return sources


    def resolve(self, url):
        return url